﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
   public enum EnumPayment { hour,month}
    public enum EnumDays {Sunday, Monday,Tuesday,Wednesday,Thursday,Friday }
}
