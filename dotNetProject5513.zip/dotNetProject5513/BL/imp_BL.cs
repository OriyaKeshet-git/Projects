﻿using BE;
using System;
using System.Collections.Generic;
using System.Linq;
using GoogleMapsApi;
using GoogleMapsApi.Entities.Directions.Request;
using GoogleMapsApi.Entities.Directions.Response;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
   
    public class imp_BL : IBL
    {
        static Random r = new Random();//help for distance (temp)
        DAL.Idal dal;
        public imp_BL()//ctor
        {
            dal = DAL.FactoryDal.GetDal();
        //init();
        }
        /// <summary>
        /// This function puts a start data in the lists
        /// </summary>
        public void init()
        {

            DateTime d = new DateTime(2000, 1, 1, 8, 20, 0);

            bool[] helpkeepingDays = new bool[6] { true, true, false, true, true, true };
            DateTime[,] helpworkHours = new DateTime[2, 6];
            for (int i = 0; i < 6; i++)
            {
                helpworkHours[0, i] = new DateTime(2000, 1, 1, 8, 0, 0);
                helpworkHours[1, i] = new DateTime(2000, 1, 1, 17, 10, 0);
            }

            this.AddNanny(new Nanny()
            {
                Id =1,
                FirstName = "Gila",
                LastName = "Cohen",
                BirthDate = new DateTime(1997, 12, 10),
                Phone = "0503223345",
                Address = "Nachal Dolev,Beit Shemesh,Isreal",
                Elevator = false,
                Floor = 1,
                ExperienceYears = 2,
                NumOfChildren = 0,
                MaxChildrens = 3,
                MinMonthesAge = 4,
                MaxMonthesAge = 30,
                BoolMoneyForHour = true,
                MoneyForHour = 50,
                MoneyForMonth =0,
                keepingDays = helpkeepingDays,
                workHours = helpworkHours,
                VacationByEducationOffice = true,
                Recommendations = "",
                mailAddress="efratna1@gmail.com"
            });

            bool[] helpkeepingDays1 = new bool[6] { true, true, false, true, true,true };
            DateTime[,] helpworkHours1 = new DateTime[2, 6];
            for (int i = 0; i < 6; i++)
            {
                helpworkHours1[0, i] = new DateTime(2000, 1, 1, 9, 0, 0);
                helpworkHours1[1, i] = new DateTime(2000, 1, 1, 16, 10, 0);
            }

            this.AddMother(new Mother()
            { Id = 2,
                FirstName = "Shola",
                LastName = "Levi",
                Phone = "0524634534",
                Address = "Yafo,Jerusalem,Isreal",
                AddressForNanny = "Yafo,Jerusalem,Isreal",
                needKeepingDays= helpkeepingDays1,
                wantedWorkHours= helpworkHours1,
                Comments = "my child need a calm nanny"
            });
            this.AddMother(new Mother()
            {
                Id = 88,
                FirstName = "Dana",
                LastName = "Levi",
                Phone = "0524484534",
                Address = "Yafo,Jerusalem,Isreal",
                AddressForNanny = "Yafo,Jerusalem,Isreal",
                needKeepingDays = helpkeepingDays1,
                wantedWorkHours = helpworkHours1,
                Comments = "my child need a calm nanny"
            });
            this.AddChild(new Child()
            {   Id = 3,
                IdMother = 2,
                FirstName = "Yosi",
                BirthDate = new DateTime(2017,6, 10),
                BoolSpecialNeeds = false,
                StringSpecialNeeds = ""
            });
            this.AddChild(new Child()
            {
                Id = 4,
                IdMother = 2,
                FirstName = "Dani",
                BirthDate = new DateTime(2016, 6, 10),
                BoolSpecialNeeds = true,
                StringSpecialNeeds = "need to sleep between 14:00 to 16:00"
            });

            this.AddContract(new Contract
            {
                IdNanny = 1,
                IdChild = 3,
                BoolMeeting = true,
                Signature = true,
                TypeOfPayment = (EnumPayment)1,
                StartDate = new DateTime(2017, 12, 12),
                EndDate = new DateTime(2018, 12, 12)
            });

        }
       
        #region Nanny Functions
        /// <summary>
        /// This function gets nanny and need to add her for NannyList only if the details of nanny legal.else,throw an Execption
        /// </summary>
        /// <param name="nanny"> The nanny that need to be added to NannyList</param>
        public void AddNanny(Nanny nanny)
        {
            if ((DateTime.Now - nanny.BirthDate).Days / 365 < 18)//the nanny is under 18 years old
                throw new Exception("the nanny is under 18 years old");
            dal.AddNanny(nanny);
        }
        /// <summary>
        /// This function gets a nanny id and need to remove her from NannyList only if this action legal.else,throw an Execption
        /// </summary>
        /// <param name="id">The id of the nanny to delete</param>
        /// <returns>True if this nanny delete successs</returns>
        public bool RemoveNanny(int id)
        {
           return( dal.RemoveNanny(id));
        }
        /// <summary>
        /// This function gets nanny and need to update her in NannyList only if the details of nanny legal.else,throw an Execption
        /// </summary>
        /// <param name="nanny">The nanny that need to be updated</param>
        public void UpdateNanny(Nanny nanny)
        {
            if ((DateTime.Now - nanny.BirthDate).Days / 365 < 18)//the nanny is under 18 years old
                throw new Exception("the nanny is under 18 years old");
            dal.UpdateNanny(nanny);
           /* List<Contract> lst = GetAllContract(co =>co.IdNanny == nanny.Id).ToList();
            for (int i = 0; i < lst.Count; i++)//updates also all the contracts that the nanny is in them
            {
                UpdateContract(lst[i]);
            }*/
        }
        /// <summary>
        /// This function gets nanny id and search the nanny in NannyList.
        /// </summary>
        /// <param name="id"> The id of the nanny to search</param>
        /// <returns>The nanny that id it's her id, null if the nanny doesn't exist</returns>
        public Nanny GetNanny(int id)
        {
            return (dal.GetNanny(id));
        }
        /// <summary>
        /// This function searches all the nannies that predicate is true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the nannies are checked by it</param>
        /// <returns>IEnumerable of all nannies that predicate is true for them</returns>
        public IEnumerable<Nanny> GetAllNanny(Func<Nanny, bool> predicate = null)
        {
            return (dal.GetAllNanny(predicate));
        }
        #endregion

        #region Mother Functions
        /// <summary>
        /// This function get mother and need to add her for MotherList only if the details of mother legal.else,throw an Execption
        /// </summary>
        /// <param name="mother">The mother that need to be added</param>
        public void AddMother(Mother mother)
        {
            dal.AddMother(mother);
        }
        /// <summary>
        /// This function get id of mother and need to remove her from MotherList only if this action legal.else,throw an Execption
        /// </summary>
        /// <param name="id">The id of the mother to delete</param>
        /// <returns>True if this mother delete success</returns>
        public bool RemoveMother(int id)
        {
            return dal.RemoveMother(id);
        }
        /// <summary>
        /// This function get mother and need to update her in MotherList only if the details of mother legal.else,throw an Execption
        /// </summary>
        /// <param name="mother">The mother that need to be updateed</param>
        public void UpdateMother(Mother mother)
        {
            dal.UpdateMother(mother);
            //foreach (var item in GetAllContract(co => GetChild(co.IdChild).IdMother == mother.Id))//updates also all the contracts that the mother has a child in them
            //{
            //    UpdateContract(item);
            //}
            /*  List<Contract> lst = GetAllContract(co => GetChild(co.IdChild).IdMother == mother.Id).ToList();
              for (int i=0;i<lst.Count;i++)//updates also all the contracts that the mother has a child in them
              {
                  UpdateContract(lst[i]);
              }*/
            List<Child> lst = GetAllChild(ch => ch.IdMother == mother.Id).ToList();
            for (int i = 0; i < lst.Count; i++)//updates also all the contracts that the mother has a child in them
            {
                UpdateChild(lst[i]);
            }
            
        }
        /// <summary>
        /// This function get mother id and search that mother in the MotherList.
        /// </summary>
        /// <param name="id">The id of the mother to search</param>
        /// <returns>The mother that id it's her id.if she does not exist it return null</returns>
        public Mother GetMother(int id)
        {
            return dal.GetMother(id);
        }
        /// <summary>
        /// This function search all the mothers that predicate is true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the mothers are checked by it </param>
        /// <returns>IEnumerable of all the mothers that predicate is true for them </returns>
        public IEnumerable<Mother> GetAllMother(Func<Mother, bool> predicate = null)
        {
            return dal.GetAllMother(predicate);
        }
        #endregion

        #region Child Functions
        /// <summary>
        /// This function get child and need to add him for ChildList only if the details of child legal.else,throw an Execption
        /// </summary>
        /// <param name="child">The child to add</param>
        public void AddChild(Child child)
        {
            if (!child.BoolSpecialNeeds)
                child.StringSpecialNeeds = "";
            if (child.BoolSpecialNeeds && (child.StringSpecialNeeds == "" || child.StringSpecialNeeds == null))
                throw new Exception("must describe the special needs!");
            if(child.BirthDate>DateTime.Now)
                throw new Exception("Illegal BirthDate");
            child.LastName = GetMother(child.IdMother).LastName;
            dal.AddChild(child);
        }
        /// <summary>
        /// This function get child id and need to delete this child from ChildList only if this action legal.else,throw an Execption
        /// </summary>
        /// <param name="id">The child to delete</param>
        /// <returns>True if this child delete success</returns>
        public bool RemoveChild(int id)
        {
           return dal.RemoveChild(id);
        }
        /// <summary>
        /// This function get child and need to update this child in ChildList only if this action legal.else,throw an Execption
        /// </summary>
        /// <param name="child">The child to be updated</param>
        public void UpdateChild(Child child)
        {
            if (!child.BoolSpecialNeeds)
                child.StringSpecialNeeds = "";
            if (child.BoolSpecialNeeds && (child.StringSpecialNeeds == "" || child.StringSpecialNeeds == null))
                throw new Exception("must describe the special needs!");
            if (child.BirthDate > DateTime.Now)
                throw new Exception("Illegal BirthDate");
            child.LastName = GetMother(child.IdMother).LastName;
            dal.UpdateChild(child);
        }
        /// <summary>
        /// This function get child id and need to find this child.
        /// </summary>
        /// <param name="id">The id of the child to search</param>
        /// <returns>Child if the child exist. else, null</returns>
        public Child GetChild(int id)
        {
            return (dal.GetChild(id));
        }
        /// <summary>
        /// This function get predicate and need to find all the children that this predicate true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the children checked by it</param>
        /// <returns>IEnumerable of all the childrens that the predicate true for them</returns>
        public IEnumerable<Child> GetAllChild(Func<Child, bool> predicate = null)
        {
           return( dal.GetAllChild(predicate));
        }
        #endregion

        #region Contract Functions
        /// <summary>
        /// This function get a contract and need to add it to ContractList only if the details of the contract legal.else, throw Exception
        /// </summary>
        /// <param name="contract">The contract to add</param>
        public void AddContract(Contract contract)
        {
            if (contract == null)
                return;
            Nanny nanny = GetNanny(contract.IdNanny);
            if (nanny == null)
                throw new Exception("the nanny is not exist");
            if (nanny.MaxChildrens <= nanny.NumOfChildren)//if the nanny already has the max children she can
                throw new Exception("the nanny has the max children");
            Child ch = GetChild(contract.IdChild);
            if (ch == null)
                throw new Exception("the child is not exist");
            Mother mother = GetMother(ch.IdMother);
            if (mother == null)
                throw new Exception("the mother is not exist");
            if ((DateTime.Now - ch.BirthDate).Days / 30 < 3)//the child is under 3 monthes old
                throw new Exception("the child is under 3 monthes old");
            int counter = 0;
            int counterDays = 0;
            for (int i = 0; i < 6; i++)//inserts the hours to the contract, the hours that in the mother hours and in the nanny hours
            {
                if (mother.needKeepingDays[i]&&nanny.keepingDays[i])
                {
                    counterDays++;
                    if (mother.wantedWorkHours[0, i] < nanny.workHours[0, i])//mother wants earlier
                        contract.WorkHours[0, i] = nanny.workHours[0, i];
                    else
                        contract.WorkHours[0, i] = mother.wantedWorkHours[0, i];
                    if (mother.wantedWorkHours[1, i] > nanny.workHours[1, i])//mother wants later
                        contract.WorkHours[1, i] = nanny.workHours[1, i];
                    else
                        contract.WorkHours[1, i] = mother.wantedWorkHours[1, i];
                    if (contract.WorkHours[1, i] < contract.WorkHours[0, i])//if in this day there are no equal hours, so we decided that the contract will not be exist
                    //
                    {
                        contract.WorkHours[0, i] = contract.WorkHours[1, i];//the start hour will be the end hour (our sign that the day in the contract is false)
                        counter++;//sum all the days that are false in the contract
                    }

                }

            }
            if(counter== counterDays)//if there are no any day that with equal hours between mother and nanny 
                throw new Exception("there are no overlapping hours beteen the nanny and the mother");
            float hours = 0;
            for (int i = 0; i < 6; i++)//sum of the hours that in the contract to put the money details in the contract
            {
                TimeSpan t = contract.WorkHours[1, i] - contract.WorkHours[0, i];
                hours += t.Hours;
                hours += (float)(t.Minutes / (60.0));
                hours += (float)(t.Seconds / (3600.0));
            }
            contract.MoneyForMonth = calculateSalary(contract);//money for month, help by function
            contract.MoneyForHour = contract.MoneyForMonth / (hours * 4);//money for hour, help by function
            if (nanny.BoolMoneyForHour)//nanny works per hour
                contract.TypeOfPayment = (EnumPayment)0;
            else//nanny works per month
                contract.TypeOfPayment = (EnumPayment)1;

            string str ="Nanny: " + nanny.FirstName + " " + nanny.LastName + "\n";
            str += "Child: " + ch.FirstName + " " + mother.LastName;
            contract.ContractBasicDetails = str;
            dal.AddContract(contract);//add the contract
            //if (GetAllBrothers(contract) != null)
            //{
            //    List<Child> temp = GetAllBrothers(contract).ToList();
            //    Contract tempContract = null;
            //    for (int i = 0; i < temp.Count; i++)//get all the brothers (of the child that his contract add) that had contract with the same nanny
            //     //and update their contract(especially the money)
            //    {
            //        tempContract = (GetAllContract().ToList()).FirstOrDefault(co => (co.IdChild == temp[i].Id && co.IdNanny == contract.IdNanny));
            //        UpdateContract(tempContract);

            //    }
            //}
        
        }
        /// <summary>
        /// This function get a number of contract and remove this contract from ContractList only if it's legal.else, throw Exception
        /// </summary>
        /// <param name="numOFContract">The number of contract to delete</param>
        /// <returns>True if the contract delete success.else, false</returns>
        public bool RemoveContract(int numOFContract)
        {
                Contract contract = GetContract(numOFContract);
                bool flag = dal.RemoveContract(numOFContract);
                List<Child> temp = GetAllBrothers(contract).ToList();
                //Contract tempContract = null;
                //if (flag)
                //{
                //    for (int i = 0; i < temp.Count; i++)//get all the brothers (of the child that his contract add) that had contract with the same nanny
                //                                        //and update their contract(especially the money)
                //    {
                //        tempContract = (GetAllContract().ToList()).FirstOrDefault(co => (co.IdChild == temp[i].Id && co.IdNanny == contract.IdNanny));
                //        UpdateContract(tempContract);

                //    }
                //}
                return flag;
        }
        /// <summary>
        /// This function get a contract and need to update this contract in ContractList only if this action legal.else, throw Exception
        /// </summary>
        /// <param name="contract">The contract to update(with the new details)</param>
        public void UpdateContract(Contract contract)
        {
            if (contract == null)
                return;
            Nanny nanny = GetNanny(contract.IdNanny);
            Child ch = GetChild(contract.IdChild);
            Mother mother = GetMother(ch.IdMother);
            if ((DateTime.Now - ch.BirthDate).Days / 30 < 3)//the child is under 3 monthes old
                throw new Exception("the child is under 3 monthes old");
            dal.UpdateContract(contract);
            string str = "Num of contract: " + contract.NumOfContractString + "\n" + "Nanny:" + nanny.FirstName + " " + nanny.LastName + "\n";
            str += "Child: " + ch.FirstName + " " + mother.LastName;
            contract.ContractBasicDetails = str;
        }
        //public void UpdateContractHours(Contract contract)
        //{
        //    if (contract == null)
        //        return;
        //    Nanny nanny = GetNanny(contract.IdNanny);
        //    Child ch = GetChild(contract.IdChild);
        //    Mother mother = GetMother(ch.IdMother);
        //    int counter = 0;
        //    for (int i = 0; i < 6; i++)//inserts the hours to the contract, the hours that in the mother hours and in the nanny hours
        //    {
        //        if (mother.needKeepingDays[i] && nanny.keepingDays[i])
        //        {
        //            if (mother.wantedWorkHours[0, i] < nanny.workHours[0, i])//mother wants earlier
        //                contract.WorkHours[0, i] = nanny.workHours[0, i];
        //            else
        //                contract.WorkHours[0, i] = mother.wantedWorkHours[0, i];
        //            if (mother.wantedWorkHours[1, i] > nanny.workHours[1, i])//mother wants later
        //                contract.WorkHours[1, i] = nanny.workHours[1, i];
        //            else
        //                contract.WorkHours[1, i] = mother.wantedWorkHours[1, i];
        //            if (contract.WorkHours[1, i] < contract.WorkHours[0, i])//if in this day there are no equal hours, so we decided that the contract will not be exist
        //            //
        //            {
        //                contract.WorkHours[0, i] = contract.WorkHours[1, i];//the start hour will be the end hour (our sign that the day in the contract is false)
        //                counter++;//sum all the days that are false in the contract
        //            }

        //        }
        //        else
        //        {
        //            contract.WorkHours[1, i] = contract.WorkHours[0, i];
        //            counter++;
        //        }

        //    }
        //    if (counter == 6)//if there are no any day that with equal hours 
        //        throw new Exception("can not update contract");
        //    float hours = 0;
        //    for (int i = 0; i < 6; i++)//check the number of hours in contract to money details in the contract
        //    {
        //        TimeSpan t = contract.WorkHours[1, i] - contract.WorkHours[0, i];
        //        hours += t.Hours;
        //        hours += (float)(t.Minutes / (60.0));
        //        hours += (float)(t.Seconds / (3600.0));
        //    }
        //    if (nanny.BoolMoneyForHour)//nanny works per hour
        //    {
        //        contract.TypeOfPayment = (EnumPayment)0;
        //        contract.MoneyForMonth = nanny.MoneyForMonth;//money for month
        //        contract.MoneyForHour = contract.MoneyForMonth / (hours * 4);//money for hour
        //    }
        //    else//nanny works per month
        //    {
        //        contract.TypeOfPayment = (EnumPayment)1;
        //        contract.MoneyForMonth = nanny.MoneyForMonth;//money for month
        //        contract.MoneyForHour = contract.MoneyForMonth / (hours * 4);//money for hour
        //    }
        //}
        /// <summary>
        /// This function get number of contract and search that contract
        /// </summary>
        /// <param name="num">The number of contract to search</param>
        /// <returns>Contract if this contract exist. else, null</returns>
        public Contract GetContract(int num)
        {
            return dal.GetContract(num);
        }
        /// <summary>
        /// This function get predicate and need to find all the contracts that this predicate true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the contracts check by</param>
        /// <returns>IEnumerable of all the contracts that the predicate true for them</returns>
        public IEnumerable<Contract> GetAllContract(Func<Contract, bool> predicate = null)
        {
            return dal.GetAllContract(predicate);
        }
        #endregion
        
        /// <summary>
        /// This function calculate the money for month according to the hours that in the contract and the type of payment of nanny(with a less payment(-2%) for every brother in the same nanny)
        /// </summary>
        /// <param name="contract">The contract that need a money Calculate </param>
        /// <returns>The money for month according this contract details</returns>
        public float calculateSalary(Contract contract)//for every other brother-2% less in payment
        {
            if (contract == null)
                return 0;
            int numOfBrothers = 0;
            Child child = GetChild(contract.IdChild);
            Mother mother = GetMother(child.IdMother);
            Nanny nanny = GetNanny(contract.IdNanny);
            IEnumerable<Child> brothers = GetAllBrothers(contract);//all the brother without the child that in the contract
            if (brothers != null)
            {
              List<Child> lst = brothers.ToList<Child>().ToList();//to list
               numOfBrothers = (lst.Count);//num of brothers
            }
            float hours = 0;
            float salary = 0;
            if (nanny.BoolMoneyForHour)//if the nanny got her salery per hour
            {
                for (int i = 0; i < 6; i++)//sum of ak the hours that nanny work to mother according the hours in contract
                {if (mother.needKeepingDays[i]&&nanny.keepingDays[i])
                    {
                        TimeSpan t = contract.WorkHours[1, i] - contract.WorkHours[0, i];
                        hours += t.Hours;
                        hours += (float)(t.Minutes / (60.0));
                        hours += (float)(t.Seconds / (3600.0));
                    }
                }
                salary = hours * (nanny.MoneyForHour) * 4;//the money for month without any reduction(if the nanny take per hour)
            }
            else
                salary = nanny.MoneyForMonth;//the money for month without any reduction(if the nanny take per month)
            return (float)(1-0.02*numOfBrothers)*salary ;//return the salary with reduction 

        }
        /// <summary>
        /// This function get contract (maybe the contract is not in the data list), and search all the brother of the child that in this contract that in the same nanny
        /// </summary>
        /// <param name="contract">The contract that the child is in it, and the func searches brotheres of it's child</param>
        /// <returns>IEnummerable of all the brother of the child that in this contract that in the same nanny</returns>
        public IEnumerable<Child> GetAllBrothers(Contract contract) 
        //but maybe the contract is not in the contract list. the child of the contract never will be in the result. 
        { if (contract == null)
                return null;
            Child child = GetChild(contract.IdChild);
            Mother mother = GetMother(child.IdMother);
            Nanny nanny = GetNanny(contract.IdNanny);
            IEnumerable<Child> brothers = GetAllChild(ch =>( ch.IdMother == child.IdMother)&&ch.Id!=child.Id);//all the brothers not include the child
            IEnumerable<Contract> nannyContracts = GetAllContract(co => co.IdNanny == contract.IdNanny);//all the contract that nanny is in them
            return from a in nannyContracts//all the brothers of this child that are in nanny
                         from b in brothers
                         where a.IdChild == b.Id
                         select b;

        }
        /// <summary>
        /// This function calculate a distance(km) betweem 2 addresses
        /// </summary>
        /// <param name="source">The address that from it calculate the distance</param>
        /// <param name="dest">The address that it calculate ths distance to</param>
        /// <returns>The distance betwwen the 2 addresses</returns>
        public float distance(string source, string dest)
        {
            //try
            //{
            //    var drivingDirectionRequest = new DirectionsRequest
            //    {
            //        TravelMode = TravelMode.Walking,
            //        Origin = source,
            //        Destination = dest,
            //    };
            //    DirectionsResponse drivingDirections = GoogleMaps.Directions.Query(drivingDirectionRequest);
            //    Route route = drivingDirections.Routes.First();
            //    Leg leg = route.Legs.First();
            //    return leg.Distance.Value;
            //}
            //catch(Exception E)
            //{
            //   throw E;
            //}
            Leg leg = null;
            try
            {
                var drivingDirectionRequest = new DirectionsRequest
                {
                    TravelMode = TravelMode.Walking,
                    Origin = source,
                    Destination = dest,

                }; DirectionsResponse drivingDirections = GoogleMaps.Directions.Query(drivingDirectionRequest);
                Route route = drivingDirections.Routes.First();
                leg = route.Legs.First();
                return (leg.Distance.Value/1000);
            }
            catch (Exception)
            {
                return -1;
            }
        }
        /// <summary>
        /// This function search for all the nannies that match to the mothers wanted hours
        /// </summary>
        /// <param name="mother">The mother that the nannies need to be match for</param>
        /// <returns>IEnumerable of all the match nannies</returns>
        public IEnumerable<Nanny> getAllWantedNannies(Mother mother)
        {
            if ( mother == null)
                throw new Exception("the mother does not exist");
            return GetAllNanny(na=>match(mother,na));//help by match function
        }
        /// <summary>
        /// This function checks if the nanny hours and days match to the mother's requests
        /// </summary>
        /// <param name="mother">The mother that the nanny need to be match for her</param>
        /// <param name="nanny">The nanny that the function checkes matching between her and the mother requests hours</param>
        /// <returns>True if the nanny match to mother requests hours to keeping.else, false</returns>
        public bool match(Mother mother, Nanny nanny)
        {
            if (nanny == null || mother == null)
                throw new Exception("the parameter does not exist");
            for (int i = 0; i < 6; i++)//check matching
            {
                if (mother.needKeepingDays[i] == true )//checks only cases that the mother wants this day (i)
                {
                    if (mother.needKeepingDays[i] == true && nanny.keepingDays[i] == false)//if the mother wants a day that the nanny does not work in it
                        return false;
                    if (mother.wantedWorkHours[0, i] < nanny.workHours[0, i])//if the mother wants a hour that the nanny does not work in it
                        return false;
                    if (mother.wantedWorkHours[1, i] > nanny.workHours[1, i])//if the mother wants a hour that the nanny does not work in it
                        return false;
                }
            }
            return true;
        }
        /// <summary>
        /// This function serches for the wanted nannies that can keep when the mother wants it if there are exist,else searches for 5 (less if there are less nanny in the date list) best match nannies
        /// </summary>
        /// <param name="mother">The mother that nannies need to be most close to her requests</param>
        /// <returns>Ienumerable for the wanted nannies that can keep when the mother wants it if there are exist,else Ienumerable for 5 (less if there are less nanny in the date list) best match nannies</returns>
        public IEnumerable<Nanny> get5BestMatchNannies(Mother mother)//maybe less than 5, if the nannies list shorter
        {
            if (mother == null)
                throw new Exception("the mother does not exist");
            IEnumerable<Nanny> match = getAllWantedNannies(mother);
            if (match.ToList().Count!= 0)//if there are nanny that works in all the hours that the mother wants it returns IEnumerable of those nannies
                return match;
            //if there are no nannies with a perfect matching;
            var v = from item in GetAllNanny()//v will contain all the nannies order by the func preferNanny, that calculates number of hours that the mother wanted
                    //but the nanny doesn't work in this time
                    orderby preferNanny(mother, item)
                    select item;

            List<Nanny> help=v.ToList<Nanny>();
            for (int i = 5; i < help.Count; i++)//takes the 5 best match nannies
            {
                help.Remove(help[i]);
            }
            return (help.AsEnumerable());

        }
        /// <summary>
        /// This function calculates the num of hours that the mother needs a nanny but this spesific nanny can not work in those hours
        /// </summary>
        /// <param name="mother">The mother that need nanny for spesific hours</param>
        /// <param name="nanny">The nanny that for her it calculates the hours</param>
        /// <returns>Num of hours that the mother need a nanny but this spesific nanny can not work in those hours</returns>
        public float preferNanny(Mother mother,Nanny nanny)
        {
            if (nanny == null|| mother== null)
                throw new Exception("the parameter does not exist");
            float sum = 0;
            TimeSpan t;
            for (int i = 0; i < 6; i++)//calculates the hours
            {
                if (mother.needKeepingDays[i] == true)//if the mother needs nanny in this day
                {
                    if (nanny.keepingDays[i] == false)//if the mother wants a day that the nanny does not work in it, takes all the hours of the mother
                    {
                        t = mother.wantedWorkHours[1, i] - mother.wantedWorkHours[0, i];
                        sum += t.Hours + (float)(t.Minutes / 60.0) + (float)(t.Seconds / 3600.0);
                    }
                    else//if the mother needs nanny in this day and the nanny keeps in this day  
                    {
                        if ((mother.wantedWorkHours[1, i] < nanny.workHours[0, i]) || (mother.wantedWorkHours[0, i] > nanny.workHours[1, i]))//if there is no any common hours between the nanny and the mother
                        {//takes all the hours of the mother
                            t = mother.wantedWorkHours[1, i] - mother.wantedWorkHours[0, i];
                            sum += t.Hours + (float)(t.Minutes / 60.0) + (float)(t.Seconds / 3600.0);
                        }
                        else// there is any common hour between the nanny and the mother
                        {
                            if ( mother.wantedWorkHours[0, i] > nanny.workHours[0, i]&& mother.wantedWorkHours[1, i] > nanny.workHours[1, i])//if the nanny starts before the mother and finish after the mother start and 
                                //before the mother finish
                            {
                                t = mother.wantedWorkHours[1, i] - nanny.workHours[1, i];
                                sum += t.Hours + (float)(t.Minutes / 60.0) + (float)(t.Seconds / 3600.0);
                            }
                            if (mother.wantedWorkHours[0, i] < nanny.workHours[0, i] && mother.wantedWorkHours[1, i] < nanny.workHours[1, i])//if the mother starts before the nanny and finish after the nanny start and 
                            //before the nanny finish 
                            {
                                t = mother.wantedWorkHours[0, i] - nanny.workHours[0, i];
                                sum += t.Hours + (float)(t.Minutes / 60.0) + (float)(t.Seconds / 3600.0);
                            }
                            if (mother.wantedWorkHours[0, i] >= nanny.workHours[0, i] && mother.wantedWorkHours[1, i] <= nanny.workHours[1, i])//if the hours of the nanny contains the hours of the mother
                            {
                                t = mother.wantedWorkHours[1, i] - mother.wantedWorkHours[0, i];
                                sum += t.Hours + (float)(t.Minutes / 60.0) + (float)(t.Seconds / 3600.0);
                            }
                            if (mother.wantedWorkHours[0, i] < nanny.workHours[0, i] && mother.wantedWorkHours[1, i] > nanny.workHours[1, i])//if the hours of the mother contains the hours of the nanny
                            {
                                t = mother.wantedWorkHours[1, i] - mother.wantedWorkHours[0, i]-(nanny.workHours[1, i] - nanny.workHours[0, i]);
                                sum += t.Hours + (float)(t.Minutes / 60.0) + (float)(t.Seconds / 3600.0);
                            }

                        }
                    }
                }
            }
            return sum;
        }
        /// <summary>
        /// This function search for all close nannies(by distance from mother that smaller than 5km) for a spesific mother
        /// </summary>
        /// <param name="mother">The mother it searches close nannies for (by "addressForNanny" if there is in mother, else address of the mother)</param>
        /// <returns>IEnumerable of all close nannies</returns>
        public IEnumerable<Nanny> getCloseNannies(Mother mother ,float radius=10)
        {
            if (mother == null)
                throw new Exception("the mother does not exist");
            string address;//address will contains the address that the mother wants for the nanny,
            //and if it is empty it will contain the address of the mother
            address = mother.AddressForNanny;
            if (mother.AddressForNanny == null)
                address = mother.Address;
            var v = from item in GetAllNanny()//v will contain all the nannies that the distance<=5 from the mother,
                    //and it will order it by the distance, 
                    let dis= distance(address, item.Address)
                    where dis <= radius
                    orderby dis
                    select item;
            //return (v.AsEnumerable());
            return (v);
        }
        /// <summary>
        /// This function searches for all the childen that don't have a nanny
        /// </summary>
        /// <returns>IEnumerable of all the children that don't have a a nanny</returns>
        public IEnumerable<Child> getAllChildWithoutNanny()
        {
            List<Child> help = GetAllChild().ToList<Child>();//all the children
            foreach (var item in GetAllContract())//for every contract-remove from help the child that his id sign there
            { 
                help.RemoveAll(ch => ch.Id == item.IdChild);
            }
            return (help.AsEnumerable<Child>());
        }
        /// <summary>
        /// This function searches for all the nannies that have a vacation by Tamat Office
        /// </summary>
        /// <returns>IEnumerable of all the nannies that has vacation by Tamat Office</returns>
        public IEnumerable<Nanny> getAllNannyVacationByTamatOffice()
        {
            var v = from a in GetAllNanny()
                    where a.VacationByEducationOffice == false//TAMAT
                    select a;
            return v;
        }
        /// <summary>
        /// This function search for all the contracts that a spesific delegate(predicate) true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the contracts are checked by it</param>
        /// <returns>IEnumerable of all the contracts that a spesific delegate(predicate) true for them</returns>
        public IEnumerable<Contract> getAllContractAccordingDelegate(Func<Contract, bool> predicate)
        {
            return (GetAllContract(predicate));
        }
        /// <summary>
        /// This function searches for the number of all the contracts that a spesific delegate(predicate) true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the contracts are checked by it</param>
        /// <returns>The number of all the contracts that a spesific delegate(predicate) true for them</returns>
        public int getNumContractAccordingDelegate(Func<Contract, bool> predicate)
        {
            return (GetAllContract(predicate).ToList<Contract>().Count);
        }
        /// <summary>
        /// grouping all the nannies by their min or max children age(it's elso can do it sorted-according the user choice), the first group can be 3 month and jump by 3 month.if a in group c, a=c or smaller than c+3
        /// </summary>
        /// <param name="max">If true, grouping by the max children age.else, grouping by the min children age </param>
        /// <param name="order">If true, grouping in order by the max or min children age.else, grouping without any order</param>
        /// <returns>IEnumerable of all the grouping</returns>
        public IEnumerable<IGrouping<float, Nanny>> GroupingNannyByAge(bool max,bool order=false)
         //the first group can be 3 month and jump by 3 month. if a in the group c, c<=a<c+3
        {
            IEnumerable<IGrouping<float, Nanny>> ageGroups=null;
            if (order && !max)//need order, grouping by min children age
            {
                ageGroups = from w in GetAllNanny()
                            orderby w.MinMonthesAge
                            group w by (float)((int)(w.MinMonthesAge / 3) * 3);
            }
            if (!order && !max)// do not need order, grouping by min children age
            {
                ageGroups = from w in GetAllNanny()
                            group w by (float)((int)(w.MinMonthesAge / 3) * 3);
            }
            if (order && max)//need order, grouping by max children age
            {
                ageGroups = from w in GetAllNanny()
                            orderby w.MaxMonthesAge
                            group w by (float)((int)(w.MaxMonthesAge / 3) * 3);
            }
            if (!order && max)//do not need order, grouping by max children age
            {
                
                ageGroups = from w in GetAllNanny()
                            group w by (float)((int)(w.MaxMonthesAge / 3) * 3);
            }
            return ageGroups;

        }
        /// <summary>
        /// grouping all the contract by their distnace(km) from mother request address(it's elso can do it sorted-according the user choice),//the first group can be 0 and jump by 5 km. if a in group c, a=c or smaller than c+5
        /// </summary>
        /// <param name="order">If it's true, grouping with order by distance.else,do not need any order</param>
        /// <returns>IEnumerable of all the grouping</returns>
        public IEnumerable<IGrouping<float, Contract>> GroupingContractByDistance(bool order = false)
         //the first group can be 0 and jump by 5 km. if a in the group c, c<=a<c+5
        {
            IEnumerable<IGrouping<float, Contract>> distanceGroups = null;

            if (order)//need order
            {
                distanceGroups = from w in GetAllContract()
                                 let mother = GetMother((GetChild(w.IdChild)).IdMother)
                                 let dis= distance(mother.AddressForNanny, GetNanny(w.IdNanny).Address)
                                 orderby dis
                                 group w by (float)(((int)(dis)/5)*5);
                //distanceGroups.ToList();
            }
            if (!order)//do not need order
            {
                distanceGroups = from w in GetAllContract()
                                 let mother = GetMother((GetChild(w.IdChild)).IdMother)
                                 group w by (float)((int)(distance(mother.AddressForNanny, GetNanny(w.IdNanny).Address) / 5) * 5);
              
            }
            return distanceGroups;
        }
        /// <summary>
        /// This function searches for all the children of spesific nanny that have a birthday in this month
        /// </summary>
        /// <param name="nanny">The nanny that it searches birthday children for</param>
        /// <returns>IEnumerable of all the children of spesific nanny that have a birthday in this month</returns>
        public IEnumerable<IGrouping<int,Child>> getAllMonthBirthdayChild(Nanny nanny)
        {
            if (nanny == null)
                throw new Exception("the nanny does not exist");
            return (from a in GetAllContract(co => co.IdNanny == nanny.Id)
                    where (GetChild(a.IdChild).BirthDate.Month == DateTime.Now.Month)
                    group GetChild(a.IdChild) by GetChild(a.IdChild).BirthDate.Day);
        }
        /// <summary>
        /// This function create a string that describe all the names of the children that have special needs,and their needs and are took care by nanny
        /// </summary>
        /// <param name="nanny">The nanny that it creates a string for "her" children</param>
        /// <returns>String of all the children that has special needs names and their special needs</returns>
        public string ChildSpecialNeeds(Nanny nanny)
        {
            if (nanny == null)
                throw new Exception("the nanny does not exist");
            string s="";
            var SpecialNeeds = from a in GetAllContract(co => co.IdNanny == nanny.Id)
                               where (GetChild(a.IdChild).BoolSpecialNeeds)
                               select a;
            foreach (var item in SpecialNeeds)
            {
                s += (GetChild(item.IdChild)).FirstName + ": " + (GetChild(item.IdChild)).StringSpecialNeeds+ "\n";
            }
            return s;
        }
        /// <summary>
        /// This function calculate the number of days that are left to the end of the contract
        /// </summary>
        /// <param name="contract">The contract that it calculate the number of days that left to the end for </param>
        /// <returns>The number of days that left to the end of contract</returns>
        public int DaysToEndOfContract(Contract contract)
        {
            if (contract == null)
                throw new Exception("the contract does not exist");
            return ((contract.EndDate - DateTime.Now).Days);
        }
        /// <summary>
        /// This function creates a string that describe all the names of the mothers their children are took care by nanny,and their comments
        /// </summary>
        /// <param name="nanny">The nanny it create string of commets for</param>
        /// <returns>String that describe all the names of the mothers their children are took care by nanny,and their comments</returns>
        public string MothersComments(Nanny nanny)
        {
            if (nanny == null)
                throw new Exception("the nanny does not exist");
            string s = "";
            var MothersComments = GetAllContract(co => co.IdNanny == nanny.Id);
            foreach (var item in MothersComments)
            {
                s += "Mother of " + GetChild(item.IdChild).FirstName + " " + GetMother(GetChild(item.IdChild).IdMother).LastName + ", ";
                s += GetMother(GetChild(item.IdChild).IdMother).FirstName+ ": "+ GetMother(GetChild(item.IdChild).IdMother).Comments+ "\n";
            }
            return s;
        }
        /// <summary>
        /// This function creates a string that describe all the names of the mothers their children are took care by nanny,and their Phones
        /// </summary>
        /// <param name="nanny">The nanny it create string for</param>
        /// <returns>String that describe all the names of the mothers their children are took care by nanny,and their Phones</returns>
        public string MothersPhones(Nanny nanny)
        {
            if (nanny == null)
                throw new Exception("the nanny does not exist");
            string s = "";
            var MothersPhones = GetAllContract(co => co.IdNanny == nanny.Id);
            foreach (var item in MothersPhones)
            {
                s += "Mother of " + GetChild(item.IdChild).FirstName +" "+ GetMother(GetChild(item.IdChild).IdMother).LastName + " ,";
                s += GetMother(GetChild(item.IdChild).IdMother).FirstName + " "  + ": " + GetMother(GetChild(item.IdChild).IdMother).Phone + "\n";
            }
            return s;
        }
        /// <summary>
        /// This function search for all the children that took care by nanny
        /// </summary>
        /// <param name="nanny">The nanny it search all children for</param>
        /// <returns>IEnumerable of all the children that took care by nanny</returns>
        public IEnumerable<Child> GetAllChildOfNanny(Nanny nanny)
        {
            if (nanny == null)
                throw new Exception("the nanny does not exist");
            return from a in GetAllContract(co => co.IdNanny == nanny.Id)
                                  select GetChild(a.IdChild);
        }

        /// <summary>
        /// This function search for all close nannies(by distance from mother that smaller than 5km) for a spesific address
        /// </summary>
        /// <param name="address">The address it searches close nannies for </param>
        /// <returns>IEnumerable of all close nannies</returns>
        public IEnumerable<Nanny> getDistanceNannies(string address, float radius = 10000)
        {if (address == "" || address == null)
                throw new Exception("the address cannot be empty");
            var v = from item in GetAllNanny()//v will contain all the nannies that the distance<=5 from the mother,
                                              //and it will order it by the distance, 
                    let dis = distance(address, item.Address)
                    where dis <= radius
                    orderby dis
                    select item;
            return (v.AsEnumerable());
        }
    }
}
