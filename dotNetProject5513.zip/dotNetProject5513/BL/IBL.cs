﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using DAL;
namespace BL
{
    public interface IBL
    {
        #region Nanny Functions
        /// <summary>
        /// This function get nanny and need to add her for NannyList only if the details of nanny legal.else,throw an Execption
        /// </summary>
        /// <param name="nanny"> The nanny that need to be added to NannyList</param>
        void AddNanny(Nanny nanny);
        /// <summary>
        /// This function get nanny id and need to remove her from NannyList only if this action legal.else,throw an Execption
        /// </summary>
        /// <param name="id">The id of the nanny to delete</param>
        /// <returns>True if this nanny delete sucsses</returns>
        bool RemoveNanny(int id);
        /// <summary>
        /// This function get nanny and need to update her in NannyList only if the details of nanny legal.else,throw an Execption
        /// </summary>
        /// <param name="nanny">The nanny that need to be updated</param>
        void UpdateNanny(Nanny nanny);
        /// <summary>
        /// This function get nanny id and search the nanny in NannyList, if she does not exist it returns null.
        /// </summary>
        /// <param name="id"> The id of the nanny to search</param>
        /// <returns>The nanny that id it's her id if she exist, else returns null </returns>
        Nanny GetNanny(int id);
        /// <summary>
        /// This function search all the nannies that predicate is true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the nannies be checked by it</param>
        /// <returns>IEnumerable of all nannies that predicate is true for them</returns>
        IEnumerable<Nanny> GetAllNanny(Func<Nanny, bool> predicate = null);
        #endregion

        #region Mother Functions
        /// <summary>
        /// This function get mother and need to add her for MotherList only if the details of mother legal.else,throw an Execption
        /// </summary>
        /// <param name="mother">The mother that need to be added</param>
        void AddMother(Mother mother);
        /// <summary>
        /// This function get id of mother and need to remove her from MotherList only if this action legal.else,throw an Execption
        /// </summary>
        /// <param name="id">The id of the mother to delete</param>
        /// <returns>True if this mother delete sucsses</returns>
        bool RemoveMother(int id);
        /// <summary>
        /// This function get mother and need to update her in MotherList only if the details of mother legal.else,throw an Execption
        /// </summary>
        /// <param name="mother">The mother that need to update</param>
        void UpdateMother(Mother mother);
        /// <summary>
        /// This function get mother id and search that mother in the MotherList and returns it,if she does not exist it return null.
        /// </summary>
        /// <param name="id">The id of the mother to search</param>
        /// <returns>The mother that id it's her id.if she does not exist it return null</returns>
        Mother GetMother(int id);
        /// <summary>
        /// This function search all the mothers that predicate is true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the mothers be checked by it </param>
        /// <returns>IEnumerable of all mothers that predicate is true for them </returns>
        IEnumerable<Mother> GetAllMother(Func<Mother, bool> predicate = null);
        #endregion

        #region Child Functions
        /// <summary>
        /// This function get child and need to add him for ChildList only if the details of child legal.else,throw an Execption
        /// </summary>
        /// <param name="child">The child to add</param>
        void AddChild(Child child);
        /// <summary>
        /// This function get child id and need to delete this child from ChildList only if this action legal.else,throw an Execption
        /// </summary>
        /// <param name="id">The child to delete</param>
        /// <returns>True if this child delete success</returns>
        bool RemoveChild(int id);
        /// <summary>
        /// This function get child and need to update this child in ChildList only if this action legal.else,throw an Execption
        /// </summary>
        /// <param name="child">The child to update</param>
        void UpdateChild(Child child);
        /// <summary>
        /// This function get child id and need to find this child.
        /// </summary>
        /// <param name="id">The id of the child to search</param>
        /// <returns>Child if the child exist. else, null</returns>
        Child GetChild(int id);
        /// <summary>
        /// This function get predicate and need to find all the children that this predicate true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the children be checked by it</param>
        /// <returns>IEnumerable of all the childrens that the predicate true for them</returns>
        IEnumerable<Child> GetAllChild(Func<Child, bool> predicate = null);
        #endregion

        #region Contract Functions
        /// <summary>
        /// This function get a contract and need to add it to ContractList only if the details of the contract legal.else, throw Exception
        /// </summary>
        /// <param name="contract">The contract to add</param>
        void AddContract(Contract contract);
        /// <summary>
        /// This function get a number of contract and remove this contract from ContractList only if it's legal.else, throw Exception
        /// </summary>
        /// <param name="numOFContract">The number of contract to delete</param>
        /// <returns>True if the contract delete success.else, false</returns>
        bool RemoveContract(int numOFContract);
        /// <summary>
        /// This function get a contract and need to update this contract in ContractList only if this action legal.else, throw Exception
        /// </summary>
        /// <param name="contract">The contract to update(with the new details)</param>
        void UpdateContract(Contract contract);
        /// <summary>
        /// This function gets number of contract and searches that contract
        /// </summary>
        /// <param name="num">The number of contract to search</param>
        /// <returns>Contract if this contract exist. else, null</returns>
        Contract GetContract(int num);
        /// <summary>
        /// This function get predicate and need to find all the contracts that this predicate true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the contracts be checked by it</param>
        /// <returns>IEnumerable of all the contracts that the predicate true for them</returns>
        IEnumerable<Contract> GetAllContract(Func<Contract, bool> predicate = null);
        #endregion

        /// <summary>
        /// This function calculate the money for month  according the hours that in the contract and the type of payment of nanny(with a less payment for brother in the same nanny)
        /// </summary>
        /// <param name="contract">The contract that need a money Calculate </param>
        /// <returns>The money for month according this contract details</returns>
        float calculateSalary(Contract contract);

        /// <summary>
        /// This function calculates a distance(km) betweem 2 addresses
        /// </summary>
        /// <param name="source">The address that from it calculate the distance</param>
        /// <param name="dest">The address that it calculate ths distance to</param>
        /// <returns>The distance betwwen the 2 addresses</returns>
        float distance(string source, string dest);

        /// <summary>
        /// This function searches for all the nannies that match to mother's wanted hours
        /// </summary>
        /// <param name="mother">The mother that the nannies need to be match for her</param>
        /// <returns>IEnumerable of all the match nannies</returns>
        IEnumerable<Nanny> getAllWantedNannies(Mother mother);

        /// <summary>
        /// This function searches for the 5 most close to the mother's wanted hours
        /// </summary>
        /// <param name="mother">The mother that nannies need to be most close to her requests</param>
        /// <returns>Ienumerable for the 5 most close nannies</returns>
        IEnumerable<Nanny> get5BestMatchNannies(Mother mother);

        /// <summary>
        /// This function search for all close nannies(by distance from mother that small from 5km) for a spesific mother
        /// </summary>
        /// <param name="mother">The mother it searches close nannies for</param>
        /// <returns>IEnumerable of all close nannies</returns>
        IEnumerable<Nanny> getCloseNannies(Mother mother, float radius=10000);

        /// <summary>
        /// This function searches for all the childen that do not have a nanny
        /// </summary>
        /// <returns>IEnumerable of all the children that do not have a nanny</returns>
        IEnumerable<Child> getAllChildWithoutNanny();

        /// <summary>
        /// This function searches for all the nannies that have vacation by Tamat Office
        /// </summary>
        /// <returns>IEnumerable of all the nannies that have vacation by Tamat Office</returns>
        IEnumerable<Nanny> getAllNannyVacationByTamatOffice();

        /// <summary>
        /// This function searches for all the contracts that a spesific delegate(predicate) true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the contracts be checked by it</param>
        /// <returns>IEnumerable of all the contracts that a spesific delegate(predicate) true for them</returns>
        IEnumerable<Contract> getAllContractAccordingDelegate(Func<Contract, bool> predicate);

        /// <summary>
        /// This function searches for the number of all the contracts that a spesific delegate(predicate) true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the contracts  be checked by it</param>
        /// <returns>The number of all the contracts that a spesific delegate(predicate) true for them</returns>
        int getNumContractAccordingDelegate(Func<Contract, bool> predicate);

        /// <summary>
        /// This function grouping all the nannies by their min or max children age(it's elso can do it sorted-according the user choice)
        /// </summary>
        /// <param name="max">If true, grouping by the max children age.else, grouping by the min children age </param>
        /// <param name="order">If true, grouping in order by the max or min children age.else, grouping without any order</param>
        /// <returns>IEnumerable of all the grouping</returns>
        IEnumerable<IGrouping<float, Nanny>> GroupingNannyByAge(bool max, bool order=false);

        /// <summary>
        /// This function grouping all the nannies by their distance(km) from mother request address(it's elso can do it sorted-according the user choice)
        /// </summary>
        /// <param name="order">If it's true, grouping with order by distance.else,do not need any order</param>
        /// <returns>IEnumerable of all the grouping</returns>
        IEnumerable<IGrouping<float, Contract>> GroupingContractByDistance( bool order = false);

        /// <summary>
        /// This function creates a string that describe all the names of the mothers their children are took care by nanny,and their Phones
        /// </summary>
        /// <param name="nanny">The nanny it creates string for</param>
        /// <returns>String that describe all the names of the mothers their children are took care by nanny,and their Phones</returns>
        string MothersPhones(Nanny nanny);

        /// <summary>
        /// This function creates a string that describe all the names of the mothers their children are took care by nanny,and their comments
        /// </summary>
        /// <param name="nanny">The nanny it creates string of comments for</param>
        /// <returns>String that describe all the names of the mothers their children are took care by nanny,and their comments</returns>
        string MothersComments(Nanny nanny);

        /// <summary>
        /// This function search for all the children of spesific nanny that have a birthday in this month
        /// </summary>
        /// <param name="nanny">The nanny it search birthday children for</param>
        /// <returns>IEnumerable of all the children of spesific nanny  that have a birthday in this month</returns>
        IEnumerable<IGrouping<int,Child>> getAllMonthBirthdayChild(Nanny nanny);

        /// <summary>
        /// This function creates a string that describe all the names of the children that have special needs,and their needs and are took care by nanny
        /// </summary>
        /// <param name="nanny">The nanny it's create a string for</param>
        /// <returns>String of all the children that has special needs names and their special needs</returns>
        string ChildSpecialNeeds(Nanny nanny);

        /// <summary>
        /// This function calculates the number of days that left to the end of contract
        /// </summary>
        /// <param name="contract">The contract that it calculate the number of days that left to the end for </param>
        /// <returns>The number of days that left to the end of contract</returns>
        int DaysToEndOfContract(Contract contract);

        /// <summary>
        /// This function gets contract and searches all the brother of the child that in this contract that in the same nanny
        /// </summary>
        /// <param name="contract">The contract that the child that the func searches brother for, is in it</param>
        /// <returns>IEnummerable of all the brother of the child that in this contract that in the same nanny</returns>
        IEnumerable<Child> GetAllBrothers(Contract contract);

        /// <summary>
        /// This function checks if the nanny hours and days match to the mother's requests
        /// </summary>
        /// <param name="mother">The mother that the nanny need to be match for</param>
        /// <param name="nanny">The nanny that the function check match between her and the mother requests</param>
        /// <returns>True if the nanny match to mother requests.else, false</returns>
        bool match(Mother mother, Nanny nanny);

        /// <summary>
        /// This function calculates the num of hours that the mother need a nanny but this spesific nanny can not work in those hours
        /// </summary>
        /// <param name="mother">The mother that need nanny for spesific hours</param>
        /// <param name="nanny">The nanny that for her it calculate the hours</param>
        /// <returns>Num of hours that the mother need a nanny but this spesific nanny can not work in those hours</returns>
        float preferNanny(Mother mother, Nanny nanny);

        /// <summary>
        /// This function search for all the children that took care by nanny
        /// </summary>
        /// <param name="nanny">The nanny it search all children for</param>
        /// <returns>IEnumerable of all the children that took care by nanny</returns>
        IEnumerable<Child> GetAllChildOfNanny(Nanny nanny);

        /// <summary>
        /// This function search for all close nannies(by distance from mother that smaller than 5km) for a spesific address
        /// </summary>
        /// <param name="address">The address it searches close nannies for </param>
        /// <returns>IEnumerable of all close nannies</returns>
        IEnumerable<Nanny> getDistanceNannies(string address, float radius = 10000);
    }
}
