﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;
using BL;
using System.Net.Mail;
using System.Net;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for ContractsWindow.xaml
    /// </summary>
    public partial class ContractsWindow : Window
    {
        IBL bl;
        public Contract contractToAdd;
        public Contract contractToUpdate;
        public ContractsWindow()
        {
            try
            {
                InitializeComponent();
                bl = FactoryBL.GetBL();
                contractToAdd = new BE.Contract();
                contractToUpdate = new BE.Contract();
                contractToAdd.StartDate = DateTime.Now;
                contractToAdd.EndDate = DateTime.Now;
                contractToUpdate.StartDate = DateTime.Now;
                contractToUpdate.EndDate = DateTime.Now;
                grid1.DataContext = contractToUpdate;
                grid2.DataContext = contractToAdd;
                refreshUpdateComboBox();
                refreshDeleteComboBox();
                refreshAdd();
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }
        public void refreshAdd()//refresh add tab 
        {
            idChildComboBox1.ItemsSource =null;
            idChildComboBox1.ItemsSource = bl.GetAllChild();
            this.idChildComboBox1.DisplayMemberPath ="ChildBasicDetails";
            idNannyComboBox1.ItemsSource = null;
            idNannyComboBox1.ItemsSource = bl.GetAllNanny();
            this.idNannyComboBox1.DisplayMemberPath ="NannyDetails";
            contractToAdd.StartDate = DateTime.Now;
            contractToAdd.EndDate = DateTime.Now;
        }
        public void refreshUpdateComboBox()//refresh update tab
        {
            this.UpdateComboBox.ItemsSource = null;
            this.UpdateComboBox.ItemsSource = bl.GetAllContract();
            this.UpdateComboBox.DisplayMemberPath = "ContractBasicDetails";
            contractToUpdate.StartDate = DateTime.Now;
            contractToUpdate.EndDate = DateTime.Now;

        }
        public void refreshDeleteComboBox()//refresh delete tab
        {
            this.DeleteComboBox.ItemsSource =null;
            this.DeleteComboBox.ItemsSource = bl.GetAllContract();
            this.DeleteComboBox.DisplayMemberPath = "ContractBasicDetails";
            this.DeleteComboBox.SelectedValuePath = "NumOfContractString";
        }
 
       
        public Contract getCopy(Contract contract)//copies contract (by value copy)
        {
            if (contract == null)
                return null;

            return (new Contract
            {
                NumOFContract = contract.NumOFContract,
                IdNanny = contract.IdNanny,
                IdChild = contract.IdChild,
                BoolMeeting = contract.BoolMeeting,
                Signature = contract.Signature,
                TypeOfPayment = contract.TypeOfPayment,
                StartDate = contract.StartDate,
                EndDate = contract.EndDate,
                MoneyForMonth = contract.MoneyForMonth,
                MoneyForHour = contract.MoneyForHour,
                WorkHoursString = contract.WorkHoursString
            });
        }
        /// <summary>
        /// send mail with contract details,when the address of the destinition is "mail"
        /// </summary>
        /// <param name="contract">the details that will be in the bode of the message</param>
        /// <param name="name">the name of the destination person</param>
        /// <param name="mail">address of the destination</param>
        private void sendMail(Contract contract, string name, string mail)
        {
            try
            {
                if (mail != null && mail != "")
                {
                    MailMessage m = new MailMessage();
                    m.Subject = "Sign Contract";
                    m.From = new MailAddress("managerbabysitter@gmail.com");
                    m.Body = "Hello " + name + " ,\nThank you for using our service.\n your new contract details are:\n" + contract.ToString() + "Have a good day!\nBabysitter service";
                    m.To.Add(mail);
                    SmtpClient smtp = new SmtpClient("smtp.gmail.com");
                    smtp.Credentials = new NetworkCredential("managerbabysitter@gmail.com", "baby12344321");//the source mail
                    smtp.EnableSsl = true;
                    smtp.Port = 587;
                    smtp.Send(m);
                }
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }
        private void addContractButton_Click(object sender, RoutedEventArgs e)//add contract click
        {
            try
            {
                if (idNannyComboBox1.SelectedItem == null || idChildComboBox1.SelectedItem == null)//if the user does not choose in the combo box
                    throw new Exception("must fill in all the details!");
                contractToAdd.IdNanny = (idNannyComboBox1.SelectedItem as Nanny).Id;
                contractToAdd.IdChild = (idChildComboBox1.SelectedItem as Child).Id;
                bl.AddContract(contractToAdd);
                MessageBox.Show("the contract namber " + contractToAdd.NumOfContractString + " is added!");
                //send mail to the nanny and to the mother
                sendMail(contractToAdd, (bl.GetMother(bl.GetChild(contractToAdd.IdChild).IdMother)).FirstName, (bl.GetMother(bl.GetChild(contractToAdd.IdChild).IdMother)).mailAddress);
                sendMail(contractToAdd, bl.GetNanny(contractToAdd.IdNanny).FirstName, bl.GetNanny(contractToAdd.IdNanny).mailAddress);
                
                //refresh
                contractToAdd = new BE.Contract();
                contractToAdd.StartDate = DateTime.Now;
                contractToAdd.EndDate = DateTime.Now;
                grid2.DataContext = contractToAdd;
                refreshAdd();
                refreshDeleteComboBox();
                refreshUpdateComboBox();
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }
        private void DeleteContractButton_Click(object sender, RoutedEventArgs e)//delete contract click
        {
            try
            {
                if (DeleteComboBox.SelectedItem != null)//the user choose a contract to deletein the combo box
                {
                    MessageBoxResult result= MessageBox.Show((bl.GetContract(int.Parse((string)DeleteComboBox.SelectedValue))).ToString()+
                                            "\nAre you sure you want to delete this contract?\n", "Warnning!", MessageBoxButton.YesNo, MessageBoxImage.Exclamation);
                        switch (result)
                        {
                            case MessageBoxResult.Yes://if the user wants to delete the contract that he chose
                            //remove the contract
                            bl.RemoveContract(int.Parse((string)DeleteComboBox.SelectedValue));
                            MessageBox.Show("the contract removed");
                            refreshAdd();
                            refreshDeleteComboBox();
                            refreshUpdateComboBox();
                            break;
                            default://else
                                break;
                        }
                    }
                else//if the user does not choose any choice in the combo box
                {
                    throw new Exception("must select contract first!");
                }
            }
            catch (Exception E)
            {
                MessageBox.Show(E.ToString());
            }
        }
        private void UpdatContractButton_Click(object sender, RoutedEventArgs e)//update contart click
        {
            try
            {
                if((UpdateComboBox.SelectedItem) as Contract==null)//if the user does not choose a contract to update
                    throw new Exception("must select contract first!");
                bl.UpdateContract(contractToUpdate);
                MessageBox.Show("the contract is updated");

                //refresh
                contractToUpdate = new Contract();
                contractToUpdate.StartDate = DateTime.Now;
                contractToUpdate.EndDate = DateTime.Now;
                grid1.DataContext = contractToUpdate;
                refreshAdd();
                refreshDeleteComboBox();
                refreshUpdateComboBox();
            }
            catch (Exception E)
            {

                MessageBox.Show(E.Message);
            }
        }
        private void UpdateComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)//selection change event of the combo box of the update
         //where the user selects a contract, it puts his details on the window
        {
            try
            {
                if (UpdateComboBox.SelectedItem != null)
                {
                    contractToUpdate = getCopy(((Contract)UpdateComboBox.SelectedItem));
                    grid1.DataContext = contractToUpdate;
                    
                }
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }
        int GetIdComboBox(object sender, RoutedEventArgs e)//return the id of the contract that is selected in the combo box
        {
            object result = this.DeleteComboBox.SelectedValue;
            if (result == null)
                throw new Exception("must select Child First");
            return (int)result;
        }

        private void searchNannyByMother_Click(object sender, RoutedEventArgs e)//open a mother window 
                                                                                //in tab personal space, when the selected mother there is the wanted mother here
        {
            try
            {
                MothersWindow help = new MothersWindow();
                help.TabControl.SelectedIndex = 3;
                help.ChooseMotherComboBox.SelectedItem = bl.GetMother((idChildComboBox1.SelectedItem as Child).IdMother);
                help.ShowDialog();
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void searchNanny_Click(object sender, RoutedEventArgs e)//open a nanny window in tab find nanny
        {
            try
            {
                NanniesWindow help = new NanniesWindow();
                help.TabControl.SelectedIndex = 4;
                help.ShowDialog();
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }
        
    }
}
