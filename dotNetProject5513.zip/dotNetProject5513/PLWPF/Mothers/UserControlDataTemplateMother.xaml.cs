﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BE;
namespace PLWPF
{
    /// <summary>
    /// Interaction logic for UserControlDataTemplateMother.xaml
    /// </summary>
    public partial class UserControlDataTemplateMother : UserControl
    {
        public UserControlDataTemplateMother()
        {
            InitializeComponent();
        }

        private void showDetails_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Mother mother = this.DataContext as Mother;
                MessageBox.Show(mother.ToString());
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }
    }
}
