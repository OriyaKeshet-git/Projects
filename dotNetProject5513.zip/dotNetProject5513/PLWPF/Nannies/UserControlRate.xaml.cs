﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for UserControlRate.xaml
    /// </summary>
    public partial class UserControlRate : UserControl
    {

        BitmapImage bitmapFull;
        BitmapImage bitmapEmpty;

        public UserControlRate()
        {
            try
            {
                InitializeComponent();

                //put the sourc images, empty star image to the bitmap emty,
                //and full star image to bitmapfull
                string ImagesPath = @"/image/כוכב מלא.png";
                Uri uri = new Uri(ImagesPath, UriKind.RelativeOrAbsolute);
                string ImagesPath2 = @"/image/כוכב צהוב.png";
                Uri uri2 = new Uri(ImagesPath2, UriKind.RelativeOrAbsolute);
                bitmapFull = new BitmapImage(uri);
                bitmapEmpty = new BitmapImage(uri2);

                //restart the images to be empty stars
                star.Source = bitmapEmpty;
                star2.Source = bitmapEmpty;
                star3.Source = bitmapEmpty;
                star4.Source = bitmapEmpty;
                star5.Source = bitmapEmpty;
                NumOfStars = 0;
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private int numOFStars;

        public int NumOfStars//amount of full stars that in the user, (will be used from outing the user(public))
        {
            get
            {
                return numOFStars;
            }
            set
            {
                numOFStars = value;
                switch (value)
                {
                    case 0:
                        star.Source = bitmapEmpty;
                        star2.Source = bitmapEmpty;
                        star3.Source = bitmapEmpty;
                        star4.Source = bitmapEmpty;
                        star5.Source = bitmapEmpty;
                        break;
                    case 1:
                        ImageButton_Click(this, null);
                        break;
                    case 2:
                        ImageButton_Click2(this, null);
                        break;
                    case 3:
                        ImageButton_Click3(this, null);
                        break;
                    case 4:
                        ImageButton_Click4(this, null);
                        break;
                    case 5:
                        ImageButton_Click5(this, null);
                        break;

                }
                star.ToolTip = numOFStars;
                star2.ToolTip = numOFStars;
                star3.ToolTip = numOFStars;
                star4.ToolTip = numOFStars;
                star5.ToolTip = numOFStars;
            }
        }

        public int NumOfStarsClick//set only in this userControl (private) (from the clicks)
        {
            get
            {
                return numOFStars;
            }
            private set
            {
                numOFStars = value;

                star.ToolTip = numOFStars;
                star2.ToolTip = numOFStars;
                star3.ToolTip = numOFStars;
                star4.ToolTip = numOFStars;
                star5.ToolTip = numOFStars;
            }
        }

        
        /// <summary>
        /// click on the first star button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImageButton_Click(object sender, RoutedEventArgs e)
        {
            if (star.Source == bitmapFull)//star is full
            {
                if (star2.Source == bitmapEmpty)//if star is full and star2 is empty, 
                {
                    star.Source = bitmapEmpty;
                    NumOfStarsClick = 0;
                }
                else//star is full and star2 is full too, empty the stars from star2 to star5
                {
                    star2.Source = bitmapEmpty;
                    star3.Source = bitmapEmpty;
                    star4.Source = bitmapEmpty;
                    star5.Source = bitmapEmpty;
                    NumOfStarsClick = 1;
                }
            }
            else//star is empty, full it
            {
                star.Source = bitmapFull;
                NumOfStarsClick = 1;
            }
        }

        /// <summary>
        /// click on star2 button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImageButton_Click2(object sender, RoutedEventArgs e)
        {
            
            if (star2.Source == bitmapFull)//if star2 is full
            {
                if (star3.Source == bitmapFull)//if star3 is full,empty the stars from star3 to star5
                {
                    
                    star3.Source = bitmapEmpty;
                    star4.Source = bitmapEmpty;
                    star5.Source = bitmapEmpty;
                    NumOfStarsClick = 2;
                }
                else//if star 3 empty ,empty star2
                {
                    star2.Source = bitmapEmpty;
                    NumOfStarsClick = 1;
                }


            }
            else//star2 is empty, full the stars from star to star2
            {
                star.Source = bitmapFull;
                star2.Source = bitmapFull;
                NumOfStarsClick = 2;
            }

        }

        /// <summary>
        /// click on star3 button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImageButton_Click3(object sender, RoutedEventArgs e)
        {
            if (star3.Source == bitmapFull)//if star3 is full
            {
                if (star4.Source == bitmapFull)//if star4 is full,empty the stars from star4 to star5
                {
                    star4.Source = bitmapEmpty;
                    star5.Source = bitmapEmpty;
                    NumOfStarsClick = 3;
                }
                else//if star 4 empty ,empty star3
                {
                    star3.Source = bitmapEmpty;
                    NumOfStarsClick = 2;
                }
            }
            else//star3 is empty, full the stars from star to star3
            {
                star.Source = bitmapFull;
                star2.Source = bitmapFull;
                star3.Source = bitmapFull;
                NumOfStarsClick = 3;
            }
        }

        /// <summary>
        /// click on star4 button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImageButton_Click4(object sender, RoutedEventArgs e)
        {
            if (star4.Source == bitmapFull)//if star4 is full
            {
                if (star5.Source == bitmapFull)//if star5 is full,empty star5
                {
                    star5.Source = bitmapEmpty;
                    NumOfStarsClick = 4;
                }
                else//if star 5 empty ,empty star4
                {
                    star4.Source = bitmapEmpty;
                    NumOfStarsClick = 3;
                }
            }
            else//star4 is empty, full the stars from star to star4
            {
                star.Source = bitmapFull;
                star2.Source = bitmapFull;
                star3.Source = bitmapFull;
                star4.Source = bitmapFull;
                NumOfStarsClick = 4;
            }

        }

        /// <summary>
        /// click on star5 button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImageButton_Click5(object sender, RoutedEventArgs e)
        {
            if (star5.Source == bitmapEmpty)//if star5 is empty, full the stars from star to star5
            {
                star.Source = bitmapFull;
                star2.Source = bitmapFull;
                star3.Source = bitmapFull;
                star4.Source = bitmapFull;
                star5.Source = bitmapFull;
                NumOfStarsClick = 5;
            }
            else//if star5 in full, empty star5
            {
                star5.Source = bitmapEmpty;
                NumOfStarsClick = 4;
            }
        }
        
    }
}
