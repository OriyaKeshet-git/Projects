﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using BE;
using DS;
using System.Xml.Linq;
using System.Reflection;
using System.ComponentModel;

namespace DAL
{
    class XML_Dal:Idal
    {
        string ContractPath = "ContractXmlBySerilalizer.xml";
        string NannyPath = "NannyXmlBySerilalizer.xml";
        string MotherPath = "MotherXmlBySerilalizer.xml";

        XElement ChildRoot;
        string ChildPath = "ChildXmlBySerilalizer.xml";
        public XML_Dal()
        {
          DataSource.ContractList = LoadFromXML <List<Contract>> (ContractPath);
          if (DataSource.ContractList != null)
            {
                int help = DataSource.ContractList.Count;
                    BE.Contract.staticNumOFContract =DataSource.ContractList[help - 1].NumOFContract+1;
            }
            else
                DataSource.ContractList = new List<Contract>();



            DataSource.NannyList = LoadFromXML<List<Nanny>>(NannyPath);
            if (DataSource.NannyList == null)
                DataSource.NannyList = new List<Nanny>();

            DataSource.MotherList = LoadFromXML<List<Mother>>(MotherPath);
            if (DataSource.MotherList == null)
                DataSource.MotherList = new List<Mother>();

            if (!File.Exists(ChildPath))
            {
                ChildRoot = new XElement("children");
                ChildRoot.Save(ChildPath);
            }
            else
            {
                try
                {
                    ChildRoot = XElement.Load(ChildPath);
                }
                catch
                {
                    throw new Exception(" Children File upload problem");
                }
            }
        }
        

        public static void SaveToXML<T>(T source, string path)
        {
            FileStream file = new FileStream(path, FileMode.Create);
            XmlSerializer xmlSerializer = new XmlSerializer(source.GetType());
            xmlSerializer.Serialize(file, source);
            file.Close();
        }

        public static T LoadFromXML<T>(string path)
        {
            if (File.Exists(path))
            {
                FileStream file = new FileStream(path, FileMode.Open);
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
                if (file.Length != 0)
                {
                    T result = (T)xmlSerializer.Deserialize(file);
                    file.Close();
                    return result;
                }
                return default(T);
            }
            else
            {
                FileStream file = new FileStream(path, FileMode.Create);
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
                file.Close();
                return default(T);
            }
        }

        XElement ConvertChildToXml(Child child)
        {
            XElement childElement = new XElement("child");

            foreach (PropertyInfo item in typeof(Child).GetProperties())
                childElement.Add
                    (
                    new XElement(item.Name, item.GetValue(child, null).ToString())
                    );

            return childElement;
        }
        Child ConvertXmlToChild(XElement element)/////////////////////////
        {
            Child child = new Child();

            foreach (PropertyInfo item in typeof(Child).GetProperties())
            {
                TypeConverter typeConverter = TypeDescriptor.GetConverter(item.PropertyType);
                object convertValue = typeConverter.ConvertFromString(element.Element(item.Name).Value);

                if (item.CanWrite)
                    item.SetValue(child, convertValue);
            }

            return child;
        }

        #region Child Functions
        /// <summary>
        /// This function gets predicate and need to find all the children that this predicate is true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the children are checked by it</param>
        /// <returns>IEnumerable of all the childrens that the predicate are true for them</returns>
        public IEnumerable<Child> GetAllChild(Func<Child, bool> predicate = null)
        {
            if (predicate == null)
            {
                return from item in ChildRoot.Elements()
                       select ConvertXmlToChild(item);
            }

            return from item in ChildRoot.Elements()
                   let s = ConvertXmlToChild(item)
                   where predicate(s)
                   select s;
        }
        /// <summary>
        /// This function gets a child and needs to add him for ChildList only if the details of child legal.else,throw an Execption
        /// </summary>
        /// <param name="child">The child to add</param>
        public void AddChild(Child child)
        {
            if (child == null)
                return;
            if (GetChild(child.Id) != null)//if the child exist
            {
                throw new Exception("this child already exist");
            }
            if (GetMother(child.IdMother) == null)//if the child does not have a mother
                throw new Exception("this child does not have a mother");

            child.ChildBasicDetails = "Id:" + child.Id + " Name: " + child.FirstName + " " + GetMother(child.IdMother).LastName;
            
            ChildRoot.Add(ConvertChildToXml(child));
            ChildRoot.Save(ChildPath);
        }
        /// <summary>
        /// This function gets a child id and need to delete this child from ChildList only if this action legal.else,throw an Execption
        /// </summary>
        /// <param name="id">The child to delete</param>
        /// <returns>True if this child delete success</returns>
        public bool RemoveChild(int id)
        {
            XElement XElementRemove = (from item in ChildRoot.Elements()
                                 where int.Parse(item.Element("Id").Value) == id
                                 select item).FirstOrDefault();
            Child childToDelete = ConvertXmlToChild(XElementRemove);
            if (childToDelete == null)//if the child to delete does not exist
                throw new Exception("this child does not exist");
            IEnumerable<Contract> help = GetAllContract(co => co.IdChild == id);//all the contract of the child 
            if (help.ToList().Count != 0)//can not remove a child that sign in contract
                throw new Exception("this child is in a contract");
            XElementRemove.Remove();
            ChildRoot.Save(ChildPath);
            return true;
           
        }
        /// <summary>
        /// This function gets a child and need to update this child in ChildList only if this action legal.else,throw an Execption
        /// </summary>
        /// <param name="child">The child to update</param>
        public void UpdateChild(Child child)
        {
            if (child == null)
                throw new Exception("this child is not exist");
            XElement XElementUpdate = (from item in ChildRoot.Elements()
                                       where int.Parse(item.Element("Id").Value) == child.Id
                                       select item).FirstOrDefault();
            if (XElementUpdate == null)
                throw new Exception("this child is not exist");
            if (GetChild(child.Id).IdMother != child.IdMother)
                throw new Exception("id mother can not be changed");
            child.ChildBasicDetails = "Id:" + child.Id + " Name: " + child.FirstName + " " + GetMother(child.IdMother).LastName;
       
            foreach (PropertyInfo item in typeof(Child).GetProperties())
                XElementUpdate.Element(item.Name).SetValue(item.GetValue(child).ToString());

            ChildRoot.Save(ChildPath);
        }
        /// <summary>
        /// This function gets a child id and need to find this child.
        /// </summary>
        /// <param name="id">The id of the child to search</param>
        /// <returns>Child if the child exist. else, null</returns>
        public Child GetChild(int id)
        {
            XElement child = (from item in ChildRoot.Elements()
                       where int.Parse(item.Element("Id").Value) == id
                       select item).FirstOrDefault();
            if (child == null)
                return null;

            return ConvertXmlToChild(child);
        }
        #endregion

        #region Contract Functions
        /// <summary>
        /// This function get predicate and need to find all the contracts that this predicate is true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the contracts are checked by it</param>
        /// <returns>IEnumerable of all the contracts that the predicate true for them</returns>
        public IEnumerable<Contract> GetAllContract(Func<Contract, bool> predicate = null)
        {
            if (predicate == null)
                return DataSource.ContractList;
            return DataSource.ContractList.Where(predicate);
        }
        /// <summary>
        /// This function gets a contract and need to add it to ContractList only if the details of the contract legal.else, throw Exception
        /// </summary>
        /// <param name="contract">The contract to add</param>
        public void AddContract(Contract contract)
        {
            if (contract == null)
                return;
            Child ch = GetChild(contract.IdChild);
            Nanny nanny = GetNanny(contract.IdNanny);
            if (ch == null || GetAllMother(mo => mo.Id == ch.IdMother).ToList().Count == 0 || GetNanny(contract.IdNanny) == null)//can not add contract that one of the people that sign there does not exist
                throw new Exception("the child or the nanny of this contract does not exist");
            if (DataSource.ContractList.FirstOrDefault(co => (co.IdNanny == contract.IdNanny && co.IdChild == contract.IdChild)) != null)//can not add contract if it already exist
                throw new Exception("the child already has a contract with this nanny");
            if (((contract.EndDate.Year < DateTime.Now.Year) || ((contract.EndDate.Year == DateTime.Now.Year) && (contract.EndDate.Month < DateTime.Now.Month)) || ((contract.EndDate.Year == DateTime.Now.Year) &&
                       (contract.EndDate.Month == DateTime.Now.Month) && (contract.EndDate.Day < DateTime.Now.Day))))
                throw new Exception("the start day already passed");
            if (contract.EndDate < contract.StartDate)//if the detials of the contract illegal
                throw new Exception("in this contract the End Date<Start Date");
            if (((DateTime.Now - ch.BirthDate).Days / 30 < nanny.MinMonthesAge || (DateTime.Now - ch.BirthDate).Days / 30 > nanny.MaxMonthesAge))//if the child that sign in contract not in the range of age of nanny
                throw new Exception("the child is not in the range age of the nanny");
            contract.NumOFContract = Contract.staticNumOFContract++;//the first num of contract is 1
            contract.ContractBasicDetails = "Num of contract: " + contract.NumOfContractString + "\n" + contract.ContractBasicDetails;
            DataSource.ContractList.Add(contract);
            nanny.NumOfChildren++;//more 1 child for the nanny
            SaveToXML(DataSource.ContractList, ContractPath);
            UpdateNanny(nanny);

        }
        /// <summary>
        /// This function gets a number of contract and remove this contract from ContractList only if it's legal.else, throw Exception
        /// </summary>
        /// <param name="numOFContract">The number of contract to delete</param>
        /// <returns>True if the contract delete success.else, false</returns>
        public bool RemoveContract(int numOFContract)
        {
            Contract contractToDelete = GetContract(numOFContract);
            if (contractToDelete == null)
                throw new Exception("this contract does not exist");
            Nanny nanny = GetNanny(contractToDelete.IdNanny);
            if (nanny == null)
                throw new Exception("the nanny does not exist");
            nanny.NumOfChildren--;//less 1 child for the nanny
            bool help = DataSource.ContractList.Remove(contractToDelete);
            SaveToXML(DataSource.ContractList, ContractPath);
            UpdateNanny(nanny);
            return help;

        }
        /// <summary>
        /// This function gets a contract and need to update this contract in ContractList only if this action legal.else, throw Exception
        /// </summary>
        /// <param name="contract">The contract to update(with the new details)</param>
        public void UpdateContract(Contract contract)
        {
            if (contract == null)
                throw new Exception("this contract does not exist");
            int index = DataSource.ContractList.FindIndex(co => co.NumOFContract == contract.NumOFContract);
            if (index == -1)
                throw new Exception("this contract does not exist");
            if (((contract.EndDate.Year < DateTime.Now.Year) || ((contract.EndDate.Year == DateTime.Now.Year) && (contract.EndDate.Month < DateTime.Now.Month)) || ((contract.EndDate.Year == DateTime.Now.Year) &&
                       (contract.EndDate.Month == DateTime.Now.Month) && (contract.EndDate.Day < DateTime.Now.Day))))
                throw new Exception("the start day already passed");
            if (contract.EndDate < contract.StartDate)//if the detials of the contract illegal
                throw new Exception("in this contract the End Date<Start Date");
            Child ch = GetChild(contract.IdChild);
            Nanny nanny = GetNanny(contract.IdNanny);
            if (ch == null || GetAllMother(mo => mo.Id == ch.IdMother).ToList().Count == 0 || GetNanny(contract.IdNanny) == null)//can not update contract that one of the people that sign there does not exist
                throw new Exception("the child or the nanny of this contract does not exist");
            if (((DateTime.Now - ch.BirthDate).Days / 30 < nanny.MinMonthesAge || (DateTime.Now - ch.BirthDate).Days / 30 > nanny.MaxMonthesAge))//if the child that sign in contract not in the range of age of nanny
                throw new Exception("the child is not in the range age of the nanny");
            DataSource.ContractList[index] = contract;

            SaveToXML(DataSource.ContractList, ContractPath);
        }
        /// <summary>
        /// This function gets number of contract and searches this contract
        /// </summary>
        /// <param name="num">The number of contract to search</param>
        /// <returns>Contract if this contract exist. else, null</returns>
        public Contract GetContract(int num)
        {
            return (DataSource.ContractList.FirstOrDefault(co => co.NumOFContract == num));
        }
        #endregion

        #region Mother Functions
        /// <summary>
        /// This function searches all the mothers that predicate is true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the mothers are checked by it</param>
        /// <returns>IEnumerable of all mothers that predicate is true for them </returns>
        public IEnumerable<Mother> GetAllMother(Func<Mother, bool> predicate = null)
        {
            if (predicate == null)
                return DataSource.MotherList;
            return DataSource.MotherList.Where(predicate);
        }
        /// <summary>
        /// This function gets a mother and needs to add her for MotherList only if the details of mother legal.else,throw an Execption
        /// </summary>
        /// <param name="mother">The mother that need to add</param>
        public void AddMother(Mother mother)
        {
            if (mother == null)
                return;
            if (GetMother(mother.Id) != null)
            {
                throw new Exception("this mother already exist");

            }
            int counter = 0;
            for (int i = 0; i < 6; i++)
            {
                if ((mother.needKeepingDays[i] == true) && mother.wantedWorkHours[1, i] < mother.wantedWorkHours[0, i])//if the details of the mother illegal
                    throw new Exception("there is an end hour that smaller than start hour ");
                if ((mother.needKeepingDays[i] == true) && (mother.wantedWorkHours[1, i] == mother.wantedWorkHours[0, i]))// && (mother.wantedWorkHours[1, i].Minute == mother.wantedWorkHours[0, i].Minute))//if the detials of the mother illegal
                    throw new Exception("there is an end hour that equal to start hour ");
                if (mother.needKeepingDays[i] == false)//checks if all the day are false
                    counter++;
            }
            if (counter == 6)//if the detials of the mother illegal
                throw new Exception("there are no days to keeping");
            DataSource.MotherList.Add(mother);
            SaveToXML(DataSource.MotherList, MotherPath);
        }
        /// <summary>
        /// This function get id of mother and need to remove her from MotherList only if this action legal.else,throw an Execption
        /// </summary>
        /// <param name="id">The id of the mother to delete</param>
        /// <returns>True if this mother delete success</returns>
        public bool RemoveMother(int id)
        {
            IEnumerable<Child> help = GetAllChild(ch => ch.IdMother == id);//get all mother children
            if (help.ToList().Count != 0)//can not delete mother if she has a child
                throw new Exception("this mother has a child");
            Mother motherToDelete = GetMother(id);
            if (motherToDelete == null)//if this mother does not exist
                throw new Exception("this mother is not exist");
            bool tmp= DataSource.MotherList.Remove(motherToDelete);
            SaveToXML(DataSource.MotherList, MotherPath);
            return tmp;
        }
        /// <summary>
        /// This function get mother and need to update her in MotherList only if the details of mother legal.else,throw an Execption
        /// </summary>
        /// <param name="mother">The mother that need to update</param>
        public void UpdateMother(Mother mother)
        {
            if (mother == null)
                throw new Exception("this mother does not exist");
            int index = DataSource.MotherList.FindIndex(mom => mom.Id == mother.Id);
            if (index == -1)//if the mother does not exist
                throw new Exception("this mother does not exist");
            int counter = 0;
            for (int i = 0; i < 6; i++)//check that all the mother detials legal.else-can not update her
            {
                if (mother.needKeepingDays[i] && mother.wantedWorkHours[1, i] < mother.wantedWorkHours[0, i])//illegal hours
                    throw new Exception("there is an end hour that smaller than start hour ");
                if ((mother.needKeepingDays[i] == true) && (mother.wantedWorkHours[1, i] == mother.wantedWorkHours[0, i]))// && (mother.wantedWorkHours[1, i].Minute == mother.wantedWorkHours[0, i].Minute))//if the detials of the mother illegal
                    throw new Exception("there is an end hour that equal to start hour ");
                if (mother.needKeepingDays[i] == false)//checks if all the day are false
                    counter++;
            }
            if (counter == 6)//illegal detials
                throw new Exception("there are no days to keeping");
            DataSource.MotherList[index] = mother;
            SaveToXML(DataSource.MotherList, MotherPath);
        }
        /// <summary>
        /// This function get mother id and search that mother in the MotherList.
        /// </summary>
        /// <param name="id">The id of the mother to search</param>
        /// <returns>The mother that id it's her id.if she does not exist it return null</returns>
        public Mother GetMother(int id)
        {
            return (DataSource.MotherList.FirstOrDefault(mo => mo.Id == id));
        }
        #endregion

        #region Nanny Functions

        /// <summary>
        /// This function searches all the nannies that predicate is true for them
        /// </summary>
        /// <param name="predicate">The predicate that all the nannies are checked by it </param>
        /// <returns>IEnumerable of all nannies that predicate is true for them</returns>
        public IEnumerable<Nanny> GetAllNanny(Func<Nanny, bool> predicate = null)
        {
            if (predicate == null)
                return DataSource.NannyList;
            return DataSource.NannyList.Where(predicate);
        }
        /// <summary>
        /// This function get nanny and need to add her for NannyList only if the details of nanny legal.else,throw an Execption
        /// </summary>
        /// <param name="nanny"> The nanny that need to add to NannyList</param>
        public void AddNanny(Nanny nanny)
        {
            if (nanny == null)
                return;
            if (GetNanny(nanny.Id) != null)//if the nanny already exist
            {
                throw new Exception("this nanny already exist");
            }
            if (nanny.MinMonthesAge > nanny.MaxMonthesAge)//if the nanny detials does not legal
                throw new Exception("the min age bigger than the max age of nanny");
            int counter = 0;
            for (int i = 0; i < 6; i++)//check if the nanny detials does not legal
            {
                if ((nanny.keepingDays[i]) && nanny.workHours[1, i] < nanny.workHours[0, i])
                    throw new Exception("there is an end hour that smaller than start hour ");
                if ((nanny.keepingDays[i]) && nanny.workHours[1, i] == nanny.workHours[0, i])
                    throw new Exception("there is an end hour that are equal to start hour ");
                if (nanny.keepingDays[i] == false)//checks if all the day are false
                    counter++;
            }
            if (counter == 6)//illegal detials
                throw new Exception("there are no days to keeping");
            DataSource.NannyList.Add(nanny);
            SaveToXML(DataSource.NannyList, NannyPath);
        }

        /// <summary>
        /// This function get nanny id and need to remove her from NannyList only if this action legal.else,throw an Execption
        /// </summary>
        /// <param name="id">The id of the nanny to delete</param>
        /// <returns>True if this nanny delete success</returns>
        public bool RemoveNanny(int id)
        {
            Nanny nannyToDelete = GetNanny(id);
            if (nannyToDelete == null)//if the nanny does not exist
                throw new Exception("this nanny does not exist");
            IEnumerable<Contract> help = GetAllContract(co => co.IdNanny == id);//all the contract that the nanny sign in
            if (help.ToList().Count != 0)//can not remove nanny that sign in contract
                throw new Exception("this nanny is in a contract");
            bool temp=DataSource.NannyList.Remove(nannyToDelete);
            SaveToXML(DataSource.NannyList, NannyPath);
            return temp;
        }

        /// <summary>
        /// This function get nanny and need to update her in NannyList only if the details of nanny legal.else,throw an Execption
        /// </summary>
        /// <param name="nanny">The nanny that need to update</param>
        public void UpdateNanny(Nanny nanny)
        {
            if (nanny == null)
                throw new Exception("this nanny does not exist");
            int index = DataSource.NannyList.FindIndex(na => na.Id == nanny.Id);
            if (index == -1)//if the nanny does not exist
                throw new Exception("this nanny is not exist");
            if (nanny.MinMonthesAge > nanny.MaxMonthesAge)//the nanny detials illegal
                throw new Exception("the min age bigger than the max age of nanny");
            int counter = 0;
            for (int i = 0; i < 6; i++)//check the nanny detials illegal
            {
                if ((nanny.keepingDays[i]) && nanny.workHours[1, i] < nanny.workHours[0, i])//illegal details
                    throw new Exception("there is an end hour that smaller than start hour ");
                if ((nanny.keepingDays[i]) && nanny.workHours[1, i] == nanny.workHours[0, i])
                    throw new Exception("there is an end hour that are equal to start hour ");
                if (nanny.keepingDays[i] == false)//checks if all the day are false
                    counter++;
            }
            if (counter == 6)//illegal details
                throw new Exception("there are no days to keeping");
            DataSource.NannyList[index] = nanny;
            SaveToXML(DataSource.NannyList, NannyPath);
        }

        /// <summary>
        /// This function get nanny id and search the nanny in NannyList.
        /// </summary>
        /// <param name="id"> The id of the nanny to search</param>
        /// <returns>The nanny that id it's her id if she exist, else null</returns>
        public Nanny GetNanny(int id)
        {
            return (DataSource.NannyList.FirstOrDefault(na => na.Id == id));
        }
        #endregion


    }
}
